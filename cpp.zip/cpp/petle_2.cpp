/*
 * petle_2.cpp
 * 
 */


#include <iostream>

using namespace std; 

int main(int argc, char **argv)
{
	
    
    
    for (int i = 11; i <= 20; i++)
         cout << " " << i <<" "; 
    
    
    
    
	return 0;
}

