/*
 * zlozonosc_alg1.cpp
 */


#include <iostream>

using namespace;

int main(int argc, char **argv)
{
	int a;
    cout << "Podaj wartość liczby a:";
    cin >> a;
    for(int a > 0; a >100)
        
	return 0;
}

